--========================================================--
-- FuridashiSearcher
-- Author: Furidashi
-- GitHub: https://github.com/FuridashiScripts
--========================================================--

local ESX = exports['es_extended']:getSharedObject()
local cooldowns = {}

local function getIdentifier(src)
    local xPlayer = ESX.GetPlayerFromId(src)
    if xPlayer then
        return xPlayer.identifier
    end
    return tostring(src)
end

ESX.RegisterServerCallback('FuridashiSearcher:server:canSearch', function(source, cb, dumpsterId)
    local identifier = getIdentifier(source)
    local key = identifier .. ':' .. tostring(dumpsterId)
    local now = os.time()
    local cooldown = (Config.CooldownMinutes or 5) * 60

    if cooldowns[key] and cooldowns[key] > now then
        cb({
            allowed = false,
            cooldownLeft = cooldowns[key] - now
        })
        return
    end

    cooldowns[key] = now + cooldown
    cb({ allowed = true })
end)

local function chooseItem()
    local total = 0

    for _, item in ipairs(Config.Reward.items) do
        total = total + item.chance
    end

    local roll = math.random(1, total)
    local current = 0

    for _, item in ipairs(Config.Reward.items) do
        current = current + item.chance
        if roll <= current then
            return item
        end
    end

    return Config.Reward.items[1]
end

RegisterNetEvent('FuridashiSearcher:server:finishSearch', function(dumpsterId)
    local src = source
    local xPlayer = ESX.GetPlayerFromId(src)

    if not xPlayer then return end

    local roll = math.random(1, 100)

    if roll <= Config.Reward.moneyChance then
        local amount = math.random(Config.Reward.money.min, Config.Reward.money.max)
        xPlayer.addMoney(amount)

        TriggerClientEvent('FuridashiSearcher:client:reward', src, {
            type = 'money',
            amount = amount
        })
        return
    end

    local item = chooseItem()
    local count = math.random(item.min, item.max)

    if GetResourceState('ox_inventory') == 'started' then
        local success = exports.ox_inventory:AddItem(src, item.name, count)

        if not success then
            TriggerClientEvent('FuridashiSearcher:client:searchFailed', src, 'Nie masz miejsca w ekwipunku.')
            return
        end
    else
        xPlayer.addInventoryItem(item.name, count)
    end

    TriggerClientEvent('FuridashiSearcher:client:reward', src, {
        type = 'item',
        name = item.name,
        label = item.label,
        count = count
    })
end)
