--========================================================--
-- FuridashiSearcher
-- Author: Furidashi
-- GitHub: https://github.com/FuridashiScripts
--========================================================--

Config = {}

-- Czas przeszukiwania w milisekundach
Config.SearchDuration = 6000

-- Cooldown jednego śmietnika dla gracza w minutach
Config.CooldownMinutes = 5

-- Maksymalny dystans interakcji ALT
Config.TargetDistance = 2.0

-- Modele śmietników/kontenerów
Config.DumpsterModels = {
    `prop_dumpster_01a`,
    `prop_dumpster_02a`,
    `prop_dumpster_02b`,
    `prop_dumpster_3a`,
    `prop_dumpster_4a`,
    `prop_dumpster_4b`,
    `prop_bin_01a`,
    `prop_bin_02a`,
    `prop_bin_03a`,
    `prop_bin_04a`,
    `prop_bin_05a`,
    `prop_bin_06a`,
    `prop_bin_07a`,
    `prop_bin_07b`,
    `prop_bin_07c`,
    `prop_bin_07d`,
    `prop_bin_08a`,
    `prop_bin_08open`,
    `prop_bin_09a`,
    `prop_bin_10a`,
    `prop_bin_10b`,
    `prop_bin_11a`,
    `prop_bin_11b`,
    `prop_bin_12a`,
    `prop_bin_13a`,
    `prop_bin_14a`,
    `prop_bin_14b`
}

Config.Animation = {
    dict = 'mini@repair',
    anim = 'fixing_a_player'
}

Config.Reward = {
    moneyChance = 40, -- % szansy na pieniądze zamiast itemu
    money = {
        min = 5,
        max = 200
    },
    items = {
        { name = 'water', label = 'Woda', min = 1, max = 2, chance = 20 },
        { name = 'bread', label = 'Chleb', min = 1, max = 1, chance = 20 },
        { name = 'beer', label = 'Piwo', min = 1, max = 1, chance = 15 },
        { name = 'cigarette', label = 'Papieros', min = 1, max = 3, chance = 15 },
        { name = 'metalscrap', label = 'Złom', min = 1, max = 3, chance = 15 },
        { name = 'lighter', label = 'Zapalniczka', min = 1, max = 1, chance = 10 },
        { name = 'phone', label = 'Stary telefon', min = 1, max = 1, chance = 5 }
    }
}

Config.StartProgress = function(data, onFinish)
    local started = exports['esx_progressbar']:Progressbar(
        data.label,
        data.duration,
        {
            FreezePlayer = true,
            animation = {
                type = "anim",
                dict = data.animation.dict,
                lib = data.animation.anim
            },
            onFinish = function()
                onFinish(true)
            end,
            onCancel = function()
                onFinish(false)
            end
        }
    )

    if started == false then
        onFinish(false)
    end
end
