--========================================================--
-- FuridashiSearcher
-- Author: Furidashi
-- GitHub: https://github.com/FuridashiScripts
--========================================================--

fx_version 'cerulean'
game 'gta5'
lua54 'yes'

author 'Furidashi'
description 'FuridashiSearcher | Dumpster Search System'
version '1.0.0'

shared_scripts {
    'config.lua'
}

client_scripts {
    'client/main.lua'
}

server_scripts {
    'server/main.lua'
}

dependencies {
    'es_extended',
    'ox_target',
    'esx_progressbar'
}
