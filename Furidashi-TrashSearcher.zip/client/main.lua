--========================================================--
-- FuridashiSearcher
-- Author: Furidashi
-- GitHub: https://github.com/FuridashiScripts
--========================================================--

local ESX = exports['es_extended']:getSharedObject()
local isSearching = false

local function notify(msg)
    ESX.ShowNotification(msg)
end

local function getDumpsterId(entity)
    local coords = GetEntityCoords(entity)
    return ('%.2f_%.2f_%.2f'):format(coords.x, coords.y, coords.z)
end

function StartDumpsterSearch(entity)
    if isSearching then return end
    isSearching = true

    local dumpsterId = getDumpsterId(entity)

    ESX.TriggerServerCallback('FuridashiSearcher:server:canSearch', function(result)
        if not result or not result.allowed then
            if result and result.cooldownLeft then
                local mins = math.ceil(result.cooldownLeft / 60)
                notify('Ten śmietnik był już przeszukiwany. Poczekaj ~y~' .. mins .. ' min~w~.')
            else
                notify('Nie możesz teraz przeszukać tego śmietnika.')
            end

            isSearching = false
            return
        end

        Config.StartProgress({
            duration = Config.SearchDuration,
            label = 'Przeszukiwanie śmietnika...',
            animation = Config.Animation
        }, function(completed)
            if completed then
                TriggerServerEvent('FuridashiSearcher:server:finishSearch', dumpsterId)
            else
                notify('Anulowano przeszukiwanie.')
                isSearching = false
            end
        end)
    end, dumpsterId)
end

CreateThread(function()
    exports.ox_target:addModel(Config.DumpsterModels, {
        {
            name = 'furidashi_searcher',
            icon = 'fa-solid fa-trash',
            label = 'Przeszukaj śmietnik',
            distance = Config.TargetDistance,
            canInteract = function(entity)
                return not isSearching and DoesEntityExist(entity)
            end,
            onSelect = function(data)
                StartDumpsterSearch(data.entity)
            end
        }
    })
end)

RegisterNetEvent('FuridashiSearcher:client:reward', function(reward)
    if reward.type == 'money' then
        notify('Znalazłeś ~g~$' .. reward.amount .. '~w~ w śmietniku.')
    elseif reward.type == 'item' then
        notify('Znalazłeś ~y~' .. reward.label .. '~w~ x' .. reward.count .. '.')
    end

    isSearching = false
end)

RegisterNetEvent('FuridashiSearcher:client:searchFailed', function(reason)
    notify(reason or 'Nie udało się przeszukać śmietnika.')
    isSearching = false
end)
